int main(){
    int a,b,c,e,d,f,g,h;
    a = 1;
    b = 2;
    c = 3;
    e = 4;
    d = 5;
    f = a+b;
    g = f+c;
    h = f+c;
    f = e+d;
    h = f+c;
    return h;
}


