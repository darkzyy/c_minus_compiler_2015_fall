int main(){
    int a = 1;
    int b;
    b = 4;
    if(a==1){
        b = 1;
    }
    else{
        b = 2;
    }
    b = read();
    if(b){
        write(1);
    }
    return b;
}
