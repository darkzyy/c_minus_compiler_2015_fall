int add(int a,int b){
    return a+b;
}
int main(){
    int n = 2,m = 3;
    int x;
    x = add(n,m);
    return x;
}
