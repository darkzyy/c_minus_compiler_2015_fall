int main(){
    int a;
    a = read();
    write(a);
    return 0;
}
