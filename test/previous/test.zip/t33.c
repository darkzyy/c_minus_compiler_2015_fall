int main(){
    int a = 2;
    int array[10];
    array[9] = 4;
    if(a==1 || a==0){
        write(1);
    }
    else{
        write(0);
    }
    a = array[9];
    if(a==3 || a==4){
        write(1);
    }
    else{
        write(0);
    }

    return 0;
}
