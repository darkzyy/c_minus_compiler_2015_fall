int main(){
    int a[4];
    a[0] = 1;
    a[1] = 2;
    a[2] = 3;
    a[3] = 4;
    write(a[0]);
    write(a[1]);
    write(a[2]);
    write(a[3]);
    return a[0];
}
