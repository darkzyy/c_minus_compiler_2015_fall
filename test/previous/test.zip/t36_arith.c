int main(){
    int a = 100;
    int b[10];
    b[0] = 9;
    write(35+45-80);
    write((35+45-80)*a);
    write((0));
    write(((0)));
    write(b[0]);
    return 0;
}
