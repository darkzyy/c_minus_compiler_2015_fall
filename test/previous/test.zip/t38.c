int main(){
    int x = 34-50;
    int y = 7*x/7-6;
    write(x);
    write(y);
    return 0;
}
