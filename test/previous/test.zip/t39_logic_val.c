int main(){
    int a,b;
    a = 1;
    if(a==1){
        write(1);
    }
    return 0;
}
