int main(){
    int a[2];
    int i = 0;
    int t;
    t = a[i];
    a[i] = a[i+1];
    a[i+1] = t;
    return 0;
}
