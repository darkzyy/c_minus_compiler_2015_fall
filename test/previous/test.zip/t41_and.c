int main(){
    int a,b;
    a=1;
    b=1;
    while(a<15 && b<2) a=a+1;
    write(1);
    a=1;
    while(a<15 && b>0) a=a+1;
    write(1);
    a=1;
    while(b<2 && a<15 ) a=a+1;
    write(1);
    a=1;
    while(b>0 && a<15 ) a=a+1;
    write(1);
    return 0;
}
